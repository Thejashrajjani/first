elements = int(input("Enter the number of elements..."))
i=1
odd=[]
even=[]
while i<=elements:
    number=int(input("enter the numbers"))
    if number%2 == 0:
        even.append(number)
    else:
        odd.append(number)

    i=i+1

print("even number is..",even)
print("odd number is..",odd)
