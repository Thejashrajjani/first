a=int(input("ENTER FIRST VALUE"))
choice = input("enter +,-,*,/,%,**,gst")
b=int(input("ENTER SECOND VALUE"))
if choice == '+':
    print("ANSWER IS :-",a+b) 
   
 
elif choice == '-':
    print("ANSWER IS :-",a-b)

elif choice == '*':
    print("ANSWER IS :-",a*b)
    
elif choice == '/':
    print("ANSWER IS :-",a/b)

elif choice == '%':
    print("ANSWER IS:-",a%b)

elif choice == '**':
    print("ANSWER IS :-",a**b)

elif choice == "gst":
     c=a+b
     gst= c*18/100
     total=c+gst
     print("total= ",total)



else:
    print("done")



   
