a=int(input("ENTER NUMBER OF PRODUCTS...."))
i=0
total=0
h=int(input("Enter the percentage of gst..."))

while i<a:
      product=int(input("ENTER PRODUCT PRICE:"))
      total=total+product
      i=i+1
   
print("total price",total)
gst=total*h/100
c=total+gst
print("TOTAL BILL INCLUDED GST....",c)
