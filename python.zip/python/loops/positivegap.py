startpoint= int(input("enter the starting point.."))
endingpoint=int(input("enter the last point..."))
gap=int(input("enter the gap that you want..."))

for i in range(startpoint,endingpoint,gap):
    print(i)
