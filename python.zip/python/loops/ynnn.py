a=['y','y','y','y','n',None,'','y','n']
total=0
sum=0
res=0
for i in a:
    total=total+1
    if i=='y':
        print("y index ",total)
        sum=sum+1
        

    elif i=='n':
        print("n index",total)
        res=res+1
    
    elif i== None:
        print("None index",total)

print("number of y is",sum)
print("number of n is",res)