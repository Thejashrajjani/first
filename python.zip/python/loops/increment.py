number=int(input("ENTER THE NUMBER OF EMPLOYEESSS..."))
i=0
increment=int(input("ENTER THE INCREMENT OF the PERCENTAGE  THAT YOU WANT"))
while i<number:
        name=input("ENTER THE NAME OF EMPLOYEESS")
        salary=int(input("ENTER THE SALARY..."))
        print(name,"=",salary)
        
        total=salary*increment/100
        bonus=salary+total
    
        print("salary with increment of the",name,"is",bonus)
        i=i+1