#teams number
#team name
#how many time play out of 10
#wins out of 10
#iff more than 5 === qualify
#o/p= qualified team

number_team=int(input("Enter the number of teams..."))
i=1
k=[]
while i<=number_team:
    team_name=input("Enter team name")
    number_play=int(input("Enter the number of times team has played out of 10"))
    number_wins=int(input("Enter how many times its winsss..."))
    if number_play < number_wins:
        print("enter valid number of winsss")
        number_wins=int(input("Enter how many times its winsss..."))

    elif number_wins > 5:
        k.append(team_name)



    i=i+1

print("Qualified teams are = ",k)