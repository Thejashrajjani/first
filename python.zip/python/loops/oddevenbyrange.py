for i in range(1,9):
    if i%2==0:
        print("even numbers areee..",i)

    else:
        print("odd numbers are",i)