
a=['csk','mi','RCB','k11']

for i in (range(len(a))):
  b=input("select the team csk,mi,RCB,k11")
  if b== 'csk':
      num=int(input("enter how many times its wins out of 12"))
      
      percentage=  num * 100 /12
      print(b,"and performanece is",percentage,"%")
      
     
  elif b== 'mi':
      num=int(input("enter how many times its wins out of 12"))
      percentage=  num * 100 /12
      print(b ,"and performanece is",percentage,"%")
  elif b== 'RCB':
      num=int(input("enter how many times its wins out of 12"))
      percentage=  num * 100 /12
      print(b ,"and performanece is",percentage,"%")
  elif b== 'k11':
      num=int(input("enter how many times its wins out of 12"))
      percentage=  num * 100 /12
      print(b ,"and performanece is",percentage,"%")
 
 
  else :
        print("enter valid name..")
    


