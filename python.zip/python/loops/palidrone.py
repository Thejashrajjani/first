number= int(input("enter the number..."))
temp=number
sum=0

while number > 0:
    digit = number % 10
    sum = sum *10 + digit
    
    number= number//10


if temp == sum:
    print("given number is palidrone...")
else :
    print("given number is not palidrone...")