number=int(input("enter the number.."))

for i in range(1,100):
   if number % i == 0 :
       
       for j in range(1,100):
           if i*j == number:
        
            print(i,"*",j,"=",number)

    