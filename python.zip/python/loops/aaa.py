y=[1,2,3]
total=0

x=sum(y)
avarage=x/len(y)



for i in y:
    total=total+i

print(total)
print(x)
print(avarage)