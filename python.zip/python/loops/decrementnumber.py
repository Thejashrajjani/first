num=int(input("enter number... : "))

while num > 0:
    num=num-1
    print(num)
