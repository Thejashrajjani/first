number= int(input("enter the number...."))
sum=0
temp = number

while temp >0:
    d = temp %10
    sum += d ** 3
    temp //= 10

if sum ==  number:
    print("given number is prime...")

else:
    print("not prime...")
     
   
