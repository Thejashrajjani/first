number=int(input("Enter the number of products...."))
i=0
egst=20
grogst=10
while i<number:
        choice= input("Enter the products catefories electronics,grocery")
        name=input(("Enter the name of products..."))
        price=int(input("Enter the price of products"))
        
        if choice == "electronics":
            gst=price*egst/100
            bill=gst+price
            print("items=",name,"bill=",bill)
        elif choice == "grocery":
            gst=price*grogst/100
            bill=gst+price
            print("items=",name,"bill=",bill)

        i=i+1 
    
        


