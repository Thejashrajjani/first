number= int(input("enter the number..."))

for i in range(1,11):
    c = number * i
    print(number,"*",i,"=",c)

