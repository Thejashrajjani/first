a=[]
string=input("Enter string:")
a.extend(string)
print(a)
i=0
b=[]
for i in range(1,len(a)+1):
    print(a[-i])
    b.append(a[-i])
    

print(b)