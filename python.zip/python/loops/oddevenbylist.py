a=[1,4,6,7,8]
for i in a:
    if i%2==0:
        print("Even",i)
    else:
        print("odd",i)
