set={'a','b','c'}
set.add('d')
print(set)
set.clear()
print(set)

#output{'d', 'b', 'a', 'c'}
#set()