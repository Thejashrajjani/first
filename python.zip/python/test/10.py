import random
def mult():
    a='0123456789'
    b='abcdefghij'
    
    l= random.choices(a)
    s= random.choices(b)

    return s,l


b= mult()
print(b)