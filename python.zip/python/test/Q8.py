#Q.8=python program to check key is already present in dictionary

di={"raj":"30","krutarth":"30"}



chr=input("enter key")

if chr in di:
    print("given key is already in dictionary")

else:
    pass
