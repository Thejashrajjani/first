print("type 0 to break")
while True:
    no=int(input("enter number.."))
    if no == 0:
        break
    else :
        pass
#output
#type 0 to break
#enter number..4
#enter number..4
#enter number..4
#enter number..0
    