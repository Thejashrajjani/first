
b=[]
c=[]
repeate=[]

length= int(input("enter the length of the list"))
for i in range(0,length):
    a=int(input("enter number.."))
    
    if a in b:
        c.append(a)
    
    b.append(a)

print("string",b)
print("repeat elemet",c)