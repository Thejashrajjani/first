import math
 
a=int(input("enter number.."))
b=int(input("enter number.."))

c=math.lcm(a,b)
print(c)