#Q4&Q5
def sort():
    a=[]
    num=int(input("how many alphaticals do you want to insert"))
    i=0
    while i<num:
        ch=input("enter words")
        a.append(ch)
        i=i+1
        
    a.sort()
    print(a)
 
def no_vowel():
   a=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','u','z']
   total=0
   for i in a:
       if i == 'a' or i == 'e' or i=='i' or i=='o' or i=='u':
         total=total+1
      
       else:
          pass
   print("number of vowel in string is",total)





choice=int(input("enter questions.."))
if choice == 1:
     sort() 

elif choice ==2:
     no_vowel()

else:
     print("invalid")


