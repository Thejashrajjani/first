#sort dictionary by value
a=[]
b=[]


num=int(input("enter the no of students"))
i=0
while i <num:
     name_student=input("enter the name")
     a.append(name_student)
     print("enter number of",name_student)
     number_student=int(input(""))
     b.append(number_student)
     i=i+1

a.sort()
print(a)
b.sort()
print(b)


z=dict(zip(a,b))
print(z)