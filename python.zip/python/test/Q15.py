#python program to shuffle deck of cards..

import random
cards=['Spade','Heart','Diamond','Club']
deck= cards * 13

shuffle=random.choices(deck)
print("shuffle cards",deck)

