#concatenate two strings ,refrence of internet to know meaning of concatenate
a=['a','b','c']
b=['d','e','f']
c=[]

for i in a:
    c.append(i)
    
for j in b:
        c.append(j)

print(c)