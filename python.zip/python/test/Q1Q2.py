#Q1 & Q2
#positive negative and zero number

#Q1. refrence from internet (what is leap year)

def leapyear():
     year=int(input("enter the year"))
     if year%4==0:
         s="given",year,"is leap year"
         return s
     
     else :
         s="this",year,"is not leap year"
         return s

def checknum():
     number=int(input("enter the number.."))
     if number > 0:
         s="positive number.."
         return s
     elif number <0:
         s="negative number.."
         return s

     elif number ==0:
         s="ZERO..."
         return s
     else :
         s="invalid"
         return s




choices=int(input("enter the Questions"))
if choices==1:
     o=leapyear()
     print(o)

elif choices ==2:
    b=checknum()
    print(b)

else :
    print("invalid..")


