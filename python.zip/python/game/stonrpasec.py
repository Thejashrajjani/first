import random

a=['st','pa','sc']


print(random(a))