letter='''Dear,%s
        You are selected
        date:<|Date|>'''
name= input ("enter your name: \n")
date=input ("enter date: \n")
letter = letter.replace("%s", name)
letter = letter.replace("<|Date|>",date)
print (letter)
