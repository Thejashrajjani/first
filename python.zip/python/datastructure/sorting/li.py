#25january





a=['abc','bcd','cvd','rfd','ggs','yy','zxc','aaa','dfd','www','yy','bcd']
b=[]
c=[]
d=[]
e=[]
y=[]
counter=0
sum=0
temp=0




for i in range(len(a)-1):

    if ord(a[i][0])<ord(a[i+1][0]):
        b.append(a[i])
    else:
        b.append(a[i+1])
        b.append(a[i])
        counter=counter+1
        break

print(b)


if counter == 1:
    for j in range(len(a)-1):
        if a[j] in b :
            pass
        else:
            if ord(a[j][0])<ord(a[j+1][0]):
                d.append(a[j])
                
            else:
                d.append(a[j])
                sum=sum+1
                break

print(d)

for k in range(len(a)-1):
 if a[k] in b:
    pass
 elif  a[k] in d:
     pass
 else:
     e.append(a[k])

     
     
print(e)





