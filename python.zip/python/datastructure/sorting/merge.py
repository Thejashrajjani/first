#divide and conquer technique
#o(n*log(n)) time complexity

#algorithm
#based on divide and conquer  technique
#step 1  divide array in half
# step 2 apply merge sort on each half to sort them recursively
# step 3 merge two parts in th one

from turtle import left, right


def merge_sort(arr):
  if len(arr) > 1:
    left_arr= arr[:len(arr)//2]
    right_arr= arr[len(arr)//2:]
    
    
    #recursion
    merge_sort(left_arr)
    merge_sort(right_arr)
        
    #merge
    i = 0 #left array index
    j = 0 #right array index
    k = 0 #merge array index
    while i < len(left_arr) and j < len(right_arr):
        if left_arr[i] < right_arr[j]:
            arr[k] = left_arr[i]
            i=i+1
          
        else:
            arr[k] = right_arr[j]
            j=j+1
        k=k+1
        
    while i < len(left_arr):
       arr[k] = left_arr[i]
       i=i+1
       k=k+1
    while j < len(right_arr):
        arr[k] = right_arr[j]
        j=j+1
        k=k+1     



a=[2,6,5,1,7,4,3]
merge_sort(a)
print(a)