a=[]
i=1
while i<=3:
    name=input("enter name:")
    a.append(name)
    i=i+1
print(a)