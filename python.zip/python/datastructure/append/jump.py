a=[-1,-0.5,0,0.5,1]
b=[1,2,3,4,5]
k=[]
for i in b:
    for j in a:
        c=i*j
        k.append(c)
     
print(k)
print(len(k))