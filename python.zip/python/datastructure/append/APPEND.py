a=int(input("ENTER NUMBER OF EMPLOYEES"))

i=0


name =[]
#storename
while i<a:
        
        name.append(input("ENTER NAME of the employees"))
        i=i+1

print