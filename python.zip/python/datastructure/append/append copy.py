a=['hello','bin','oop']
b=[]

reversed(b)
b.append(a)
print(b)