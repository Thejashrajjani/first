from cgi import print_form
from operator import le
from re import I
from typing import Counter


a=['abc','bcd','cvd','rfd','ggs','yy','zxc','aaa','dfd','www','yy','bcd']
sum=0
b=[]
c=[]
d=[]
p=[]
forward_pointer=0
counter=0
for i in range(len(a)-1):
    
    if ord(a[i][0])<ord(a[i+1][0]):
        b.append(a[i])
    else:
        b.append(a[i])
   
        sum=sum+1
        forward_pointer=sum+1
        z=a[i+forward_pointer]
        counter=counter+1
        break

print(b) #['abc', 'bcd', 'cvd', 'rfd', 'ggs']

