list = [1,3,5,6,7]

if 8 in list:
    print(True)
else:
    print(False)