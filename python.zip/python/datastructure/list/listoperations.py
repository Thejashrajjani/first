#opration1 add element

k=['raj','riya']
name=input("enetr name.")
k.append(name)
print(k)

#opeartion2 deleting element

no=input("enetr name taht you want delete")
k.remove(no)
print(k)


#operation3 reverse string

k.reverse()
print(k)


