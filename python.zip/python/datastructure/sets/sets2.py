#addingremovingelements
elements=set(["hello","who","ok","done"])
elements.add("lo")
elements.discard("hello")
print(elements)