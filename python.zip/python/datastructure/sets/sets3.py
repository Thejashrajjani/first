#unionAndintersection
a=set([1,2,3,5,6])
b=set([2,5,6,7,8,4])

c=a&b
print(c)

d=a|b
print(d)

e=a-b
print(e)

f=b-a
print(f)

