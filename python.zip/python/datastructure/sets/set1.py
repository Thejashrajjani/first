elements=set(["mon","wenes","tues","sat"])
print(elements)




#for d in elements:
 #   print(d)