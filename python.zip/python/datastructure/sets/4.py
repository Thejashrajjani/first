a=set(["h","o","y"])
b=set(["a","b","c","d"])

c= a<= b
print(c)