


def ip():#input function
    var1=int(input("enter variable 1"))
    var2=int(input("enter variable 2"))
    choice=int(input("enter choiice 1= + , 2= -,3= *,4=%"))
    
    process(var1,var2,choice)#call variable that we use in nxt function

def process(var1,var2,choice):
    if choice == 1:
        c=var1 + var2
    elif choice == 2:
        c= var1 - var2
    elif choice == 3:
        c= var1 * var2
    elif choice == 4:
        c= var1 % var2
    op(c)       
    

def op(c):
    print(c)
   

ip()