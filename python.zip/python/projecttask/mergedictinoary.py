

b={'a','b','c'}
c=(1,2,3)
d=list(c)
e=list(b)
a=[]
for i in range(0,len(d)):
    x=e[i],d[i]
    
    a.append(x) 
    f=dict(a)
    
print(f)