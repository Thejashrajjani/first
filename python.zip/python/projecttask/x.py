
# for row in range(0,6):
#     for columm in range(1,6):
#         if columm == row or row+columm== 6:
#             print("*",end=" ")
#         else:
#             print(' ',end=" ")
#     print("")



print("*       *")
print(" *     *  ")
print("   *  *  ")
print("     *    ")
print("    *  *   " )
print("   *     *")