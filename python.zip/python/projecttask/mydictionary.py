a={'a':400,'b':300,'c':100,'d':600}
c={}



b=int(input("Enter the number:"))


for i in a:
    if a[i] > b:
        print("value with higher number ",i,a[i])
        
        
        

        
        
    
    

 