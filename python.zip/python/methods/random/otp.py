import random
a='1234567890'


while True:
        mobile_number= (input("enter mobile number"))
        length= len(mobile_number)
        if length == 10:
               b= random.sample(a,4)
               print(" ".join(b))
               break
        else :
             print("enetr the valid number..")
        

