class cricket:
    
    def _init_(self):
        self.__met()

    def argu(self):
        print('cricket is popular in india')

    def __met(self):
        print('i hate cricket')
class hocky:
    def myfun(self):
        print("hocky is indian national game ")

obj = cricket()
obj.argu()
# obj.__met()  not accessible as it is set to private
g=hocky()
# it will override from cricket is popular in india to hocky is indian national game 
g.myfun()