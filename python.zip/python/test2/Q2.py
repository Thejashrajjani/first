#atleast 8 characters
# containing special characters,numbers,alphabets.

import re


while True:
    
    password=input("enter password")
    if len(password)<8:#minium 8 characters
       print("your password is not match with our requirements")
    elif not re.search("[a-z]",password):#contains alphabetricals
       
        print("your password must have alphabeticals..")
        break 
    elif not re.search("[0-9]",password):#contains numbers
        
        print("your password must have numbers")
        break
    elif not re.search("[0-9]",password):#contains numbers
        
        print("your password must have numbers")
        break
    elif not re.search("[_@]",password):#contains specialcharacter
        
        print("your password must have specailcharacter")
        break 
   
   
    else:
         
         print("valid password..")
         break