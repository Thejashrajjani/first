#8) Build a program which sqaures the numbers of [5,6,7,8] using *args.
a=[5,6,7,8]
square=[i**2 for i in a]
print(square)