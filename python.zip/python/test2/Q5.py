# #Q5.
# try.txt: 
# IDE: We recommend having an environment ready, so you can solve problems outside of browser.
# Resources: You can use help files and other resources that you normally use. 
a=open('try.txt','r')
e=a.readline()
c=open('one.txt','w')
z=c.write(e)


