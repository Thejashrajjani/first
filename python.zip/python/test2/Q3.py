#q3
#selectionsort
a=[6,7,9,1,2,3]
print(a)
for i in range(0,len(a)):
    for j in range(i,len(a)):
        if a[i] > a[j]:
            a[i],a[j] = a[j],a[i]
            print(a)