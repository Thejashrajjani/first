#7 Build a stopwatch using datetime module.



import time
def time_convert(seconds):
  minutes = seconds // 60
  seconds = seconds % 60
  hours = minutes // 60
  minutes = minutes % 60
  print("Time passed = {0}:{1}:{2}".format(int(hours),int(minutes),seconds))
input("Enter to start stopwatch")
start_time = time.time()
input(" Enter to stop stopwatch")
end_time = time.time()
time_lapsed = end_time - start_time
time_convert(time_lapsed)
