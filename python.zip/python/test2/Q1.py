#Q1
#pattern

#no of rows =6
#no of max columns = 11
no_rows=6

for rows in range(0,6):
    for column in range(no_rows-rows-1):
        print(' ',end='')
    for iiner in range(2*rows+1):
        print('*',end='')
    print(" ")