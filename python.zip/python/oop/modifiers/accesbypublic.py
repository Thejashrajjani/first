
# program to illustrate public access modifier in a class

class abc():#superclass
    
  def __init__(self,name,age):#create constructor
      
      #publicdata member
      self.myname= name #myname and myage are public data
      self.myage= age
      
    #display function or public member function
  def displayage(self):
        #accessing datamember
        print("AGE = ",self.myage)
        
# creating object of the class       
obj = abc("RAJ",21)

# accessing public data member
print("Name: ",obj.myname)


# calling public member function of the class
obj.displayage()
