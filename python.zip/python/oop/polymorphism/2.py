#implemet method overloading with same class
