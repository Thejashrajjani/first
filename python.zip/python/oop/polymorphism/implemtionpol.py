class A:
    def __init__(self):
        self.s="Winter is comming !"
    def display(self):
        print(self.s)
class B:
    def __init__(self):
        self.s="winter is comming"
    def display(self):
        print(self.s)

A().display()
B().display()