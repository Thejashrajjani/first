#map function
def prime(i):
    if  i==2 or i ==3 or i ==5 or i==7:
        n=i,'prime'
    elif  i%2==0 or i%3==0 or i%5==0 or i%7==0:
        n=i,'not prime'
    else:
        n=i,'prime'
    return n


a=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]
prime=list(map(prime,a))
print(prime)
    