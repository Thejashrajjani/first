a=[1,2,3,4,5,6,7,8,9,10,11,12]
#1,3,5,7,2,11
for i in a:
 
    d=list(filter(lambda i: i==2 or i ==3 or i ==5 or i==7 or i==1 or i==11,a))
    
    
    
print(d)
