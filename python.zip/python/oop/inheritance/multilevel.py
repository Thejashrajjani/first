class Base:
    def __init__ (self) :
      self.name="Sophie Turner"
    def display (self) :
        print (self.name)
class Derivedl (Base) :
    def disp (self) :
            print ("Derivedl method")
class Derived2 (Derivedl):
    def showMessage (self) :
        print ("Derived2 method")
o1=Derived2 ()
o1.display()
o1.disp()
o1.showMessage ()
