




class student():
    def name(self,s):
        self.s=s
        return self.s
        
        
    def marks(self,maths,science,english):
        self.maths=maths
        self.science=science
        self.english=english
        return self.maths,self.english,self.science
                
        
    def avarage(self):
        c= self.maths+self.science+self.english
        d=c/3
        return d
        
    
    
    
    
class working_student(student):
    def salary(self,sal):
        self.sal=sal
        super().name(sal)
        print(myobj.name("jani"))
        print(myobj.marks(30,40,50))
        print(myobj.avarage())
        
        
        
        
        return sal
    
    



myobj2= working_student()
print(myobj2.salary(20000))