class base():
    a=6
    def one(self,z,y,x):
        self.z=z
        self.y=y
        self.x=x
        print(self.x+self.y+self.z)
    def two(self):
        return self.z+self.y
    def three(self):
        return self.z

class Base2(base):
    def two(self,q,w,e):

        super().one(q,w,e)
        return q,w,e
    def four(self):
        return "hiii"

newobj=Base2()
print(newobj.two(4,5,6))
