class Basel:
    def __init__(self):
        self.name="Aegon Targaryen"
    def display (self) :
        print (self.name)
class Base2:
        def initialize (self) :
            self.n="Daenerys Targaryen"
        def disp (self) :
            print (self.n)
class Derived (Basel, Base2) :
    def show (self):
        print ("I have two base classes")
o=Derived ()
o. initialize()
o.show ()
o.display()
o.disp()