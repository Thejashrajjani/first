class Base1:
    def __init__(self):
        self.name="Raj jani"
    def display(self):
        print(self.name)
class Derived1(Base1):
    def disp(self):
        print("derived method from Base1")
        
class  Base2:
    def __init__(self):
        self.name="Rose Leslie"
    def show(self):
        print(self.name)
    
class Derived2(Base2):
    def showMessage(self):
        print("derived method of Base2")
    
o1=Derived1()
o2=Derived2()
o1.display()
o1.disp()
o2.show()
o2.showMessage()

        