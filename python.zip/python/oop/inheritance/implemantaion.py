#syntax
#class Base:
    #base class body

#syntax to inheritance class,Base from class, Derived

#class Derived(Base):
#derived class body


#implemntaions


class Base:
    def __init__(self):
        self.name="Raj jani"
    
    def display(self):
        print(self.name)


class Derived(Base):#inheritance from class base
    def display(self):
        print("derived method")

o=Derived() #derived class object
o.display() #base class method
o=Base()
o.display()