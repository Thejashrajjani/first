class A:
    def __init__(self,name):
        print(f"{name} class A ")
    def f1(self):
        print("f1")
class B(A):
    def __init__(self,name1):
        print(f"{name1} class B")    
    def f2(self):
        print("f1 new")
class C(B):
    def __init__(self,name2):
        print(f"{name2} class C")
    def f2(self):
        super().f2()
        print("f2 new")

c1=C("abc")
c1.f2()
print()
b=B("xyz")
b.f1()
b.f2()

