class B:
    def f(self):
        print("Inside B")
    def f2(self):
        print("new")
class C:
    def f1(self):
        print("Inside C")
    def f2(self):
        print("Inside c twice")
class D(C,B):
    def f(self):
        super().f2()
        super().f()
        print("Inside D")
d=D()
d.f()
d.f2()




