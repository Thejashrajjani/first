class employee:
    def __init__(self,aname,aid,adepartment):
        self.aname=aname
        self.aid=aid
        self.adepartment=adepartment
    def sho(self):
        print(self.aname)
        print(self.aid)
        print(self.adepartment)
class manager(employee):
    def __init__(self,name,emp_salary,manager_id,):
        self.name=name
        self.emp_salary=emp_salary
        self.manager_id=manager_id
    def sho(self):
        print(self.name)
        print(self.emp_salary)
        print(self.manager_id)
class ceo(manager):
        def __init__(self,name3):
            self.name3=name3
        def s(self):
            super().sho()
            print("new")
            
            
c1=ceo("raj")
c1.s()
print(c1)

# b=manager("xyz")
# b.sho()

