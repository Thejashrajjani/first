class mycal:
    def __init__(self,p):
        self.p=p

    def display(self):
        return self.p
    def __del__(self):
        def dis(self):
            return self.p
        
        
o1=mycal(int(input("enter number..")))
o2=mycal(int(input("enter number")))

print(o1.display())
print(o2.display())



del(o1)        
print(o2.display())


