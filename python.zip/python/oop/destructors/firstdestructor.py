class myclass:
    def __init__(self,q,p):
        self.q=q
        self.p=p
    def disp(self):
        return self.q,self.p
    def __del__(self):
        print("destroyed..")

o1=myclass(input("enter string..\n"),int(input("enter number..")))
o2=myclass(input("enter string..\n"),int(input("enter number..")))
print(o1.disp())
print(o2.disp())
del(o1)
print(o1.disp())
print(o2.disp())