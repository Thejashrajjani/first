class A:
    def __init__(self):
        self.s="Winter is comming !"
    def display(self):
        print(self.s)
class B(A):
    def __init__(self):
        self.s="winter is comming"
    # def __del__(self):
    #     A.display(self)
        
    
    
    def display(self):
        return self.s


obj=B()

print(obj)