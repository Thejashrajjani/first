#27january
class Myclass:
    def __init__(self,q,p):
        self.q=q
        self.p=p
    def disp(self):
        return self.q,self.p


o1=Myclass(input("enter String 1:\n"),int(input("enter number 1:\n")))
o2=Myclass(input("enter String 2:\n"),int(input("enter number 2:\n")))
print(o1.disp())
print(o2.disp())