


class Employee():
    no_of_leves= 8
    def display(self):
    
        return self.name, self.salary , self.role

no_of_emplo=int(input("enter number of employee"))
i=0

while i < no_of_emplo:
    a= Employee()   
    name=input("enter name..")
    a.name=Employee()
    salary=int(input("enter salarry.."))
    a.salary=Employee()
    role=input("enter the role..")
    a.role=Employee()
    a.display()
    i=i+1


