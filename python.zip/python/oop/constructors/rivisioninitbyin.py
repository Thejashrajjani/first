class Employee:
    #constructor function
    def __init__(self,aname,asalary,arole):#arguments in brackets
        self.name=aname #aname is an arguments
        self.salary=asalary #asalary is an arguments
        self.role=arole #arole is an arguments
    
    
        
a=input("enter name")
b=int(input("Enter salary"))
c=input("enter role")      
na= Employee(a,b,c)
        
print(na.salary)
print(na.name)
print(na.role)



# enter namejani 
# Enter salary50000
# enter rolephysicist 
# 50000
# jani
# physicist