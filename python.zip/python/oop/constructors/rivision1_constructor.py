


class Employee:
    no_leves = 8
    def display(self):
        return self.name , self.salary , self.role
        

raj = Employee()
tower = Employee()


raj.name= "Raj"
raj.salary= "100000"
raj.role= "physicist"


tower.name = "tower"
tower.salary="100000"
tower.role="Developer"

print(raj.display())
print(tower.display())


# Output
# ('Raj', '100000', 'physicist')
# ('tower', '100000', 'Developer')