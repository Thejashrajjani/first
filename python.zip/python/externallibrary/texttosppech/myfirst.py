
from gtts import gTTS
import os

mytext = "raj"
language= 'en'

output = gTTS(text=mytext, lang=language, slow=False) 

output.save('audio.mp3')

